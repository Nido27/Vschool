var app = angular.module("app.signin", ["ngRoute", "authModule", "tokenModule"]);

app.config(function($routeProvider) {
  $routeProvider.when("/signin", {
    templateUrl: "/views/signin.tpl.html",
    controller: "signinCtrl"
  });
});


app.controller("signinCtrl", function($scope, authSerivce, TokenService) {
  $scope.userinput = {};
  $scope.signin = function() {
    var data = {
      username: $scope.userinput.username,
      password: $scope.userinput.password
    }
    authSerivce.signin(data).then(function(response) {
      TokenService.save(response.data.token);
      $scope.userinput = {};
    }, function(response) {
      console.log(response.status);
    })
  };

});
