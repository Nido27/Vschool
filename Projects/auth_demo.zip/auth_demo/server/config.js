module.exports = {
  secret: "jacob cant spEl",
  database: "auth"
}
