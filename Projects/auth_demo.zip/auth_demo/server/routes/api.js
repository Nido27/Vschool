var express = require("express");
var apiRouter = express.Router();
var adminPriv = require("../middleware/adminPriv.js");

//import model
var Todo = require("../models/todoSchema.js");


apiRouter.get("/", function(req ,res) {
  Todo.find({}, function(err, data) {
    if(err) {
      res.status(500).send(err);
    } else {
      res.status(200).send({"message": "Success", data: data});
    }
  })
});


apiRouter.post("/", function(req, res) {
  var newTodoItem = new Todo(req.body);
  newTodoItem.save(function(err,data){
    if(err) {
      res.status(500).send(err);
    } else {
      res.status(200).send({"message": "Success", data: data});
    }
  });
});
apiRouter.use(adminPriv);

apiRouter.put("/:id", function(req, res) {
  Todo.findOne({_id: req.params.id}, function(err, data) {
    if(err) {
      res.status(500).send(err);
    } else {
      for(key in req.query) {
        data[key] = req.query[key];
      }
      data.save(function(err,data){
        if(err) {
          res.status(500).send(err);
        } else {
          res.status(200).send({"message": "Success", data: data});
        }
      });
    }
  })
});

apiRouter.delete("/:id", function(req, res) {
  Todo.findOne({_id: req.params.id}, function(err, data) {
    if(err) {
      res.status(500).send(err);
    } else {
      data.remove(function(err,data){
        if(err) {
          res.status(500).send(err);
        } else {
          res.status(200).send({"message": "Success", data: data});
        }
      });
    }
  })
});


module.exports = apiRouter;
